# Gerar o APK do Saldo Certo pelo celular

1. Crie uma conta em GitHub e um repositório chamado `saldo-certo`.
2. Envie **todos os arquivos desta pasta** para o repositório (não envie o ZIP dentro do repositório).
3. No GitHub, abra **Actions**.
4. Se aparecer a confirmação para habilitar workflows, confirme.
5. Abra **Gerar APK Android** e toque em **Run workflow**.
6. Aguarde terminar com status verde.
7. Abra a execução concluída e procure **Artifacts**.
8. Baixe `saldo-certo-apk`.
9. Extraia o ZIP baixado e instale `app-debug.apk` no Android.

O APK é uma instalação real. Para distribuição pela Google Play e atualizações automáticas, será necessário configurar assinatura/release e publicar o app na Play Store.
