import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.com.saldocerto.app',
  appName: 'Saldo Certo',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#f8fafc',
  },
};

export default config;
