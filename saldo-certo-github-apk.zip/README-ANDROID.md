# Saldo Certo — Android

Este projeto foi preparado para ser empacotado como aplicativo Android instalável usando Capacitor.

## Recursos preservados
- Receitas, despesas, categorias e orçamentos continuam usando o armazenamento local existente.
- PIN continua usando o armazenamento local existente.
- Service Worker mantém o PWA com cache/offline quando executado como web app.
- No Android/Capacitor, o conteúdo é empacotado dentro do APK e abre como aplicativo instalado, sem depender de um atalho do navegador.

## Gerar o Android

Após instalar as dependências:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, gere o APK em **Build > Build APK(s)**.

Para publicação e atualização automática, publique o aplicativo na Google Play e aumente a versão a cada release.
